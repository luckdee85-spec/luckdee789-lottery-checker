const form=document.getElementById("check-form");
const input=document.getElementById("ticket");
const result=document.getElementById("result");
document.getElementById("year").textContent=new Date().getFullYear();

let lotteryData=null;
async function loadResults(){
  try{
    const response=await fetch("./data/results.json",{cache:"no-store"});
    if(!response.ok) throw new Error("โหลดข้อมูลไม่สำเร็จ");
    lotteryData=await response.json();
  }catch(error){
    result.textContent="ยังไม่สามารถโหลดข้อมูลผลรางวัลได้ โปรดลองใหม่ภายหลัง";
  }
}
function checkTicket(ticket,data){
  const matches=[];
  const prizes=data.prizes||{};
  if((prizes.first||[]).includes(ticket)) matches.push("รางวัลที่ 1");
  if((prizes.near_first||[]).includes(ticket)) matches.push("รางวัลข้างเคียงรางวัลที่ 1");
  for(let n=2;n<=5;n++) if((prizes["prize_"+n]||[]).includes(ticket)) matches.push("รางวัลที่ "+n);
  if((prizes.front3||[]).includes(ticket.slice(-3))) matches.push("เลขหน้า 3 ตัว");
  if((prizes.last3||[]).includes(ticket.slice(-3))) matches.push("เลขท้าย 3 ตัว");
  if((prizes.last2||[]).includes(ticket.slice(-2))) matches.push("เลขท้าย 2 ตัว");
  return matches;
}
form.addEventListener("submit",async event=>{
  event.preventDefault();
  const ticket=input.value.trim();
  if(!/^\d{6}$/.test(ticket)){result.textContent="กรุณากรอกหมายเลขสลากให้ครบ 6 หลัก";return;}
  if(!lotteryData) await loadResults();
  if(!lotteryData) return;
  const matches=checkTicket(ticket,lotteryData);
  result.className="result"+(matches.length?" win":"");
  if(matches.length){
    result.innerHTML=`หมายเลข <strong>${ticket}</strong><br>พบผลตรงกัน: <strong>${matches.join(", ")}</strong><br><small>งวดวันที่ ${lotteryData.draw_date||"ไม่ระบุ"}</small>`;
  }else{
    result.textContent=`หมายเลข ${ticket} ไม่พบรางวัลในชุดข้อมูลที่มีอยู่ (งวด ${lotteryData.draw_date||"ไม่ระบุ"})`;
  }
});
loadResults();