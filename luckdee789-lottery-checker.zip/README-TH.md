# LUCKDEE789 Lottery Checker

ระบบตัวอย่างตรวจสลากแบบ Static Website ใช้ HTML, CSS และ JavaScript เหมาะสำหรับนำไปเผยแพร่ผ่าน GitHub Pages แล้วลิงก์จาก WordPress.com Free

## ไฟล์
- `index.html` หน้าเว็บ
- `style.css` รูปแบบสีน้ำเงิน-ทอง
- `app.js` การตรวจเลข
- `data/results.json` ข้อมูลผลรางวัล

## สำคัญ
ชุดข้อมูลเริ่มต้นยังว่างอยู่ ระบบจึงยังไม่สามารถตรวจผลจริงได้จนกว่าผู้ดูแลจะเพิ่มผลรางวัลที่ตรวจสอบแล้วลงใน `data/results.json` ทุกงวด

อย่าใส่ API key หรือรหัสผ่านลงใน repository สาธารณะ ตรวจสอบสิทธิ์การใช้ข้อมูลและเงื่อนไขของแหล่งผลรางวัลก่อนนำไปใช้ โดยเฉพาะกรณีมีโฆษณาหรือหารายได้

## เผยแพร่ด้วย GitHub Pages
1. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดโดยคงโครงสร้างเดิม
2. เปิด Settings ของ repository
3. เลือก Pages
4. ใน Build and deployment เลือก Deploy from a branch
5. เลือก branch `main` และ folder `/ (root)` แล้วกด Save
6. รอ GitHub สร้างเว็บไซต์ แล้วเปิด URL ที่แสดงในหน้า Pages
